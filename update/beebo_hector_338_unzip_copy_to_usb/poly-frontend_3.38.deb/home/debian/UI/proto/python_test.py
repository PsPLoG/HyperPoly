def bend1(x, a):
   x += 0.25
   x += a * math.sin(x * 2.0 * math.pi) / (2.0 * math.pi)
   x -= 0.25
   return x

def bend2(x, a):
   x += a * math.sin(x * 2.0 * math.pi) / (2.0 * math.pi)
   return x

def bend3(x, a):
   a = 0.5 * a
   x = x - a * x * x + a
   x = x - a * x * x + a
   return x

response_model = rdflib.Graph(namespace_manager=ingen_wrapper.ingen.ns_manager)
response_model.parse(StringIO(response_str), 'ingen:/', format='n3')
# Add new prefixes to prepend to future responses because rdflib sucks
for line in response_str.split('\n'):
    if line.startswith('@prefix'):
        match = re.search('@prefix ([^:]*): <(.*)> *\.', line)
        if match:
            name = match.group(1)
            uri  = match.group(2)
            ingen_wrapper.ingen.ns_manager.bind(match.group(1), match.group(2))

blanks        = []
response_desc = []
for i in response_model.triples([None, NS.rdf.type, NS.patch.Response]):
    response = i[0]
    subject  = response_model.value(response, NS.patch.subject, None)
    body     = response_model.value(response, NS.patch.body, None)
    response_desc += [i]
    blanks        += [response]
    if body != 0:
        print(body, msg)

blank_closure = []
for b in blanks:
    blank_closure += self.blank_closure(response_model, b)

for b in blank_closure:
    for t in response_model.triples([b, None, None]):
        response_model.remove(t)

for i in response_desc:
    response_model.remove(i)

ingen_wrapper.ingen.update_model(response_model)

@prefix atom: <http://lv2plug.in/ns/ext/atom#> .
@prefix doap: <http://usefulinc.com/ns/doap#> .
@prefix ingen: <http://drobilla.net/ns/ingen#> .
@prefix lv2: <http://lv2plug.in/ns/lv2core#> .
@prefix midi: <http://lv2plug.in/ns/ext/midi#> .
@prefix owl: <http://www.w3.org/2002/07/owl#> .
@prefix patch: <http://lv2plug.in/ns/ext/patch#> .
@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .

 _:b5
        a patch:Put ;
        patch:sequenceNumber "17"^^xsd:int ;
        patch:subject </main/notify> ;
        patch:body [
                ingen:canvasX "159.0"^^xsd:float ;
                ingen:canvasY "32.0"^^xsd:float
        ] .

@prefix atom: <http://lv2plug.in/ns/ext/atom#> .
@prefix doap: <http://usefulinc.com/ns/doap#> .
@prefix ingen: <http://drobilla.net/ns/ingen#> .
@prefix lv2: <http://lv2plug.in/ns/lv2core#> .
@prefix midi: <http://lv2plug.in/ns/ext/midi#> .
@prefix owl: <http://www.w3.org/2002/07/owl#> .
@prefix patch: <http://lv2plug.in/ns/ext/patch#> .
@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .

_:b6
	a patch:Put ;
	patch:sequenceNumber "31"^^xsd:int ;
	patch:subject </main/Mono> ;
	patch:body [
		ingen:canvasX "724.0"^^xsd:float ;
		ingen:canvasY "553.0"^^xsd:float ;
		lv2:prototype <http://gareus.org/oss/lv2/convoLV2#Mono> ;
		a ingen:Block
	] .

@prefix atom: <http://lv2plug.in/ns/ext/atom#> .
@prefix doap: <http://usefulinc.com/ns/doap#> .
@prefix ingen: <http://drobilla.net/ns/ingen#> .
@prefix lv2: <http://lv2plug.in/ns/lv2core#> .
@prefix midi: <http://lv2plug.in/ns/ext/midi#> .
@prefix owl: <http://www.w3.org/2002/07/owl#> .
@prefix patch: <http://lv2plug.in/ns/ext/patch#> .
@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .

_:b6

	a patch:Set ;
	patch:subject </main/Mono/gain> ;
	patch:property ingen:value ;
	patch:value "-0.18798956"^^xsd:float .

#####
@prefix atom: <http://lv2plug.in/ns/ext/atom#> .
@prefix doap: <http://usefulinc.com/ns/doap#> .
@prefix ingen: <http://drobilla.net/ns/ingen#> .
@prefix lv2: <http://lv2plug.in/ns/lv2core#> .
@prefix midi: <http://lv2plug.in/ns/ext/midi#> .
@prefix owl: <http://www.w3.org/2002/07/owl#> .
@prefix patch: <http://lv2plug.in/ns/ext/patch#> .
@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .
_:b6
	a patch:Put ;
	patch:sequenceNumber "447"^^xsd:int ;
	patch:subject </main/Mono/gain> ;
	patch:body [
		ingen:value "-0.21932115"^^xsd:float ;
		lv2:index "2"^^xsd:int ;
		a lv2:ControlPort ,
			lv2:InputPort
	] .

	a patch:Put ;
	patch:sequenceNumber "67"^^xsd:int ;
	patch:subject </main/Mono/gain> ;
	patch:body [
		ingen:value "-0.1"^^xsd:float
	] .

#####
@prefix atom: <http://lv2plug.in/ns/ext/atom#> .
@prefix doap: <http://usefulinc.com/ns/doap#> .
@prefix ingen: <http://drobilla.net/ns/ingen#> .
@prefix lv2: <http://lv2plug.in/ns/lv2core#> .
@prefix midi: <http://lv2plug.in/ns/ext/midi#> .
@prefix owl: <http://www.w3.org/2002/07/owl#> .
@prefix patch: <http://lv2plug.in/ns/ext/patch#> .
@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .
_:b6
	a patch:Put ;
	patch:sequenceNumber "22"^^xsd:int ;
	patch:subject </main/> ;
	patch:body [
		a ingen:Arc ;
		ingen:tail </main/Mono/out> ;
		ingen:head </main/Delay/left_in>
	] .

a patch:Put ;
	patch:sequenceNumber "439"^^xsd:int ;
	patch:subject </main/mvclpf1/out_gain> ;
	patch:body [
		ingen:value "0.0"^^xsd:float ;
		lv2:index "10"^^xsd:int ;
		a lv2:ControlPort ,
			lv2:InputPort
	] .

_:b1631
	a patch:Put ;
	patch:sequenceNumber "451"^^xsd:int ;
	patch:subject </main/audio_out_1> ;
	patch:body [
		ingen:canvasX "718.0"^^xsd:float ;
		ingen:canvasY "558.0"^^xsd:float ;
		lv2:index "2"^^xsd:int ;
		lv2:name "Audio Out 1" ;
		a lv2:AudioPort ,
			lv2:OutputPort
	] .

pass
g = rdflib.ConjunctiveGraph()
g.parse(StringIO(a), format="n3")
# if put
# find subject
# find values
# connections
a = ingen_wrapper.ingen._get_prefixes_string() + ingen_wrapper.ingen.recv();print(a)

    a = ingen_wrapper.ingen._get_prefixes_string() + ingen_wrapper.ingen.recv();print(a);parse_ingen(a)



import ingen_wrapper
import queue
ui_messages = queue.Queue()
ingen_wrapper.start_recv_thread(ui_messages)

ingen_wrapper.ingen.get("/main")



	a patch:Put ;
	patch:sequenceNumber "2121"^^xsd:int ;
	patch:subject </engine> ;
	patch:body [
		ingen:maxRunLoad "0.0"^^xsd:float ;
		ingen:meanRunLoad "0.0"^^xsd:float ;
		ingen:minRunLoad "0.0"^^xsd:float
	] .

