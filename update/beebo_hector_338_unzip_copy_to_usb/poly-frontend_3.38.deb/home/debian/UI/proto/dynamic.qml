import QtQuick 2.0
import QtQuick.Window 2.0
import QtQuick.Controls 2.3

ApplicationWindow {
    id: window
    width: 720
    height: 1280
    minimumHeight: 1280
    minimumWidth: 720
    maximumHeight: 1280
    maximumWidth: 720
    visible: true
    title: "DIGIT"
    
    Item {
        id: grid_2d
        width:400
        height:400
        property Item focusedRectangle;

        Rectangle {
            id: addButton
            color: Qt.rgba(0,1,0,0.6)
            width: parent.width; height: 50
            Text { text: "add"; anchors.centerIn: parent }
            MouseArea {
                anchors.fill: parent
                onPressed: {
                    console.debug("pressed");
                    rectModel.append( {text: rectModel.count} )
                }
            }
        }

        Item {
            width: parent.width
            anchors.top: addButton.bottom
            anchors.bottom:  resetButton.top
            z: -1
            property Item currentItem

            Text {
                anchors.centerIn: parent
                font.pointSize: 15

                color: Qt.rgba(0,0,0,0.4);
                text: "Add an item, then click here..."
            }

            MouseArea {
                anchors.fill: parent
                onReleased: {
                    grid_2d.focusedRectangle = null;
                    console.debug("item released");
                }
                onPositionChanged: moveItem(mouse);
                function moveItem (mouse) {
                    if (grid_2d.focusedRectangle !== null)
                    {
                        focusedRectangle.setPos(mouse.x, mouse.y);
                    }
                }
            }

            Repeater {
                id: rects
                model: ListModel { id: rectModel }

                delegate: Rectangle {
                    id: item
                    width:50; height:50
                    color: Qt.rgba( Math.random(), Math.random(), Math.random(), 0.5);

                    Text {
                        anchors.centerIn: parent
                        text: model.text
                    }

                    // Behavior on x { SmoothedAnimation { velocity: 500 } }
                    // Behavior on y { SmoothedAnimation { velocity: 500 } }

                    function setPos(x, y) { item.x = x; item.y = y; posChanged(x,y); }

                    signal posChanged(real x, real y);

                    MouseArea {
                        anchors.fill: parent
                        onPressed: {
                            console.debug("item pressed");
                            grid_2d.focusedRectangle = item;
                        }
                    }

                }


                onItemAdded: {
                    parent.currentItem = item;
                    item.x = Math.random() * (parent.width - item.width);
                    item.y = Math.random() * (parent.height - item.height);
                    console.debug("item added");
                }
            }

        }

        Rectangle {
            id: resetButton
            color: Qt.rgba(1,0,0,0.6)
            width: parent.width; height: 50
            anchors.bottom: parent.bottom
            Text { text: "clear"; anchors.centerIn: parent }
            MouseArea {
                property bool flag
                flag: false
                anchors.fill: parent
                onPressed: rectModel.clear();
            }
        }

    }
}
